export const USER_STATUSES_TEMPLATE = {
    ACTIVE: ' ✅ Active',
    EXPIRED: ' ⚠️ Expired',
    DISABLED: '❌ Disabled',
    LIMITED: '🔴 Limited',
} as const;
