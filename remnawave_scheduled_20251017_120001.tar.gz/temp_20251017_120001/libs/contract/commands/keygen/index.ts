export * from './get-pubkey.command';
