export const XRAY_CONTROLLER = 'xray' as const;

export const XRAY_ROUTES = {
    GET: '',
    UPDATE: '',
} as const;
