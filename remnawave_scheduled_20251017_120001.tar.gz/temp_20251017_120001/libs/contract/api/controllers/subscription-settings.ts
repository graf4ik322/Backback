export const SUBSCRIPTION_SETTINGS_CONTROLLER = 'subscription-settings' as const;

export const SUBSCRIPTION_SETTINGS_ROUTES = {
    GET: '',
    UPDATE: '',
} as const;
