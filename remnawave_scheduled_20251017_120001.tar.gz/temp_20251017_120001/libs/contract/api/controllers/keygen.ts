export const KEYGEN_CONTROLLER = 'keygen' as const;

export const KEYGEN_ROUTES = {
    GET: '',
} as const;
