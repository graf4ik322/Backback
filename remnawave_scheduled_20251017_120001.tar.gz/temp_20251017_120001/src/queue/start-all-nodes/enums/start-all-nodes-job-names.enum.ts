export enum StartAllNodesJobNames {
    startAllNodes = 'startAllNodes',
}
