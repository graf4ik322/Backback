export enum BulkUserOperationsJobNames {
    resetUsersTraffic = 'resetUsersTraffic',
    revokeUsersSubscription = 'revokeUsersSubscription',
    updateUsers = 'updateUsers',
}
