export enum ExpireUserNotificationsJobNames {
    expireUserNotifications = 'expireUserNotifications',
}
