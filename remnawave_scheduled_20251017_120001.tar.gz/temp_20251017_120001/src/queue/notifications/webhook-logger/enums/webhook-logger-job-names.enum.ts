export enum WebhookLoggerJobNames {
    sendWebhook = 'sendWebhook',
}
