export interface IBaseWebhookLogger {
    payload: string;
    timestamp: string;
}
