export * from './base-webhook-logger.interface';
