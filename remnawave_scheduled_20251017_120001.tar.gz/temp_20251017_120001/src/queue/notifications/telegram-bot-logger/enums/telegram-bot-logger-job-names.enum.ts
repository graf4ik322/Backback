export enum TelegramBotLoggerJobNames {
    sendTelegramMessage = 'sendTelegramMessage',
}
