export enum StartNodeJobNames {
    startNode = 'startNode',
}
