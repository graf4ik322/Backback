export interface RecordNodeUsagePayload {
    nodeUuid: string;
    nodeAddress: string;
    nodePort: number | null;
}
