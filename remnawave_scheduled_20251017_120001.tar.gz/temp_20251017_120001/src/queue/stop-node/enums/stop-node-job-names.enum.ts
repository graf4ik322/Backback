export enum StopNodeJobNames {
    stopNode = 'stopNode',
}
