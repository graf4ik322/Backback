export enum NodeHealthCheckJobNames {
    checkNodeHealth = 'checkNodeHealth',
}
