export enum ServiceJobNames {
    CLEAN_OLD_USAGE_RECORDS = 'cleanOldUsageRecords',
}
