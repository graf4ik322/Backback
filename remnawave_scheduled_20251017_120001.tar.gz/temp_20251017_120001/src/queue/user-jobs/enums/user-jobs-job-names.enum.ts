export enum UserJobsJobNames {
    findExceededUsers = 'findExceededUsers',
    findExpiredUsers = 'findExpiredUsers',
    findUsersForThresholdNotification = 'findUsersForThresholdNotification',
}
