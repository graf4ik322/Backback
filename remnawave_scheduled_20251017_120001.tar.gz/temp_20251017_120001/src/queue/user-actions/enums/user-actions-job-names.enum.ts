export enum UserActionsJobNames {
    bulkDeleteByStatus = 'bulkDeleteByStatus',
}
