export enum ResetUserTrafficJobNames {
    resetDailyUserTraffic = 'resetDailyUserTraffic',
    resetMonthlyUserTraffic = 'resetMonthlyUserTraffic',
    resetNoResetUserTraffic = 'resetNoResetUserTraffic',
    resetWeeklyUserTraffic = 'resetWeeklyUserTraffic',
}
