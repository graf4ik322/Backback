export enum NodeUsersJobNames {
    addUserToNode = 'addUserToNode',
    removeUserFromNode = 'removeUserFromNode',
}
