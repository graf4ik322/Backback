export enum FirstConnectedUsersJobNames {
    handleFirstConnectedUsers = 'handleFirstConnectedUsers',
}
