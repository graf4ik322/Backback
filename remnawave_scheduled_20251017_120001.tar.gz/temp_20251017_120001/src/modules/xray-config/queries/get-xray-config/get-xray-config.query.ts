export class GetXrayConfigQuery {
    constructor() {}
}
