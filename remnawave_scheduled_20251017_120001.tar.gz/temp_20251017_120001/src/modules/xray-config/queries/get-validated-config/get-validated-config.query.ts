export class GetValidatedConfigQuery {
    constructor() {}
}
