export class GetConfigResponseModel {
    public config: object;

    constructor(config: object) {
        this.config = config;
    }
}
