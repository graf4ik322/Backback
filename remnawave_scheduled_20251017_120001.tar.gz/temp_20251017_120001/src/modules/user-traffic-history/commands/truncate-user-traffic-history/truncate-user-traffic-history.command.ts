export class TruncateUserTrafficHistoryCommand {
    constructor() {}
}
