import { CleanOldUsageRecordsTask } from './clean-old-usage-records/clean-old-usage-records.task';

export const SERVICE_JOBS_TASKS = [CleanOldUsageRecordsTask];
