import { RolesGuard } from './roles.guard';

export { RolesGuard };
