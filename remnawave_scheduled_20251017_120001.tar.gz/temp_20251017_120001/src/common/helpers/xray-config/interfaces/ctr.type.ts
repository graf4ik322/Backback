export type TCtrXRayConfig = object | Record<string, unknown> | string;
