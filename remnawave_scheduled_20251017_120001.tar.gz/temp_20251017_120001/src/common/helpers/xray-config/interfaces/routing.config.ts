export interface FallbackObject {
    alpn?: string;
    dest?: number | string;
    path?: string;
    xver?: number;
}
