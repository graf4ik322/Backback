export * from './prisma.module';
